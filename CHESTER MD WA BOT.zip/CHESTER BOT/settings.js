const settings = {
  packname: 'SJ CHECKERS',
  author: 'SJ CHECKERS',
  botName: "JOELCHESTER-MD",
  botOwner: 'JOEL CHESTER', 
  timezone: 'Africa/KAMPALA',
  prefix: '.',
  ownerNumber: '256790547127', 
  AUTO_STATUS_REACT: 'true',
  AUTO_STATUS_REPLY: 'false',
  AUTO_STATUS_MSG: 'Status Viewed Chester ft Checkers',

  AUTORECORD: 'true',
  AUTOTYPE: 'true',
  AUTORECORDTYPE: 'true',
  

  

  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;
